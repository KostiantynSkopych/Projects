Dana symulacja została wykonana w ramach projektu studenckiego na przedmioce Matematyka dla Przemysłu.
Głównym celem projektu było badanie odpowiedzi na pytanie: Z jaką prędkością najlepiej poruszać się w deszczu
żeby zmoknąć jaknajmniej. Lub krócej: Biec czy iść w deszczu. 
GUI symuluje poruszanie się człowieka w deszczu w zależności od podanych parametrów. Zakładamy tutaj że wiatr
wieje nam prosto w twarz (ujemna wartość prędkości) lub prosto w plecy (dodatnia wartość prędkości). Parametry
mają domyślne wartości które można odczytać z kodu programu.
Pod koniec symulacji GUI wyświetla wyniki w postaci ilości zużytej energii na pokonanie drogi, ilości zużytego
czasu oraz ilości wody która spadła na człowieka w trakcie poruszania się. 