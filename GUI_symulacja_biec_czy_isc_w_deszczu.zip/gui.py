#   ATTENTION!!! FOR BETTER EXPERIENCE USE PYTHON 3.7

from tkinter import *
import tkinter as tk
import tkinter.ttk as ttk
from PIL import ImageTk, Image #pip install pillow
import os
import platform
import pygame
import time
import sys
import numpy as np

def loadImage(name, useColorKey=False):
    image = pygame.image.load(name)
    image = image.convert() #przekonwertuj na format pikseli ekranu
    if useColorKey is True:
        colorkey = image.get_at((0,0)) #odczytaj kolor w punkcie (0,0)
        image.set_colorkey(colorkey) # ustaw kolor jako przezroczysty
    return image
    
def isfloat(str):
    try:
        float(str)
        return True
    except ValueError:
        return False

SCREEN_WIDTH = 1000
SCREEN_HEIGHT = 430

def findmet(v):
    result = 0
    if v <= 0.75:
        result = 2.3
    elif v > 0.75 and v <= 1.1:
        result = 2.9
    elif v > 1.1 and v <= 1.4:
        result = 3.3
    elif v > 1.4 and v <= 1.55:
        result = 3.6
    elif v> 1.55 and v <= 1.8:
        result = 5
    elif v > 1.8 and v <= 2.2:
        result = 8
    elif v > 2.2 and v <= 2.7:
        result = 10
    elif v > 2.7 and v <= 3.5:
        result = 13
    elif v > 3.5 and v <= 5:
        result = 16
    else:
        result = 20
    return result

class Ludzik(pygame.sprite.Sprite):
    def __init__(self):
        # Inicjalizuje klasę bazową Sprite
        pygame.sprite.Sprite.__init__(self)
        self.ims = [loadImage("1.png",True),loadImage("2.png",True),loadImage("3.png",True),\
                loadImage("4.png",True),loadImage("5.png",True),loadImage("6.png",True)]
        self.image = self.ims[0]
        self.rect = self.image.get_rect() #rozmiar rysunku
        self.rect.center = (SCREEN_WIDTH*0.05,0.87*SCREEN_HEIGHT) #gdzie wstawić?
        self.velocity = 1.5

    def update(self):
        self.rect.move_ip((self.velocity,0)) #move in-place
        
class Raindrop(pygame.sprite.Sprite):

    def __init__(self,startpos):
        #inicjalizuje klasę bazową Sprite
        pygame.sprite.Sprite.__init__(self)
        self.image = loadImage("kr.png",True)
        self.rect = self.image.get_rect()
        self.rect.center = startpos
        self.x=-1
        self.y=5
    
    def update(self):
        if self.rect.bottom >= SCREEN_HEIGHT-20:
            self.kill()
        elif self.rect.right >= SCREEN_WIDTH:
            self.kill()
        elif self.rect.right <= 0:
            self.kill()
        else:
            self.rect.move_ip((self.x,self.y)) #move raindrop
        

class Application:
    def __init__(self):
        ''' Okienko i parametry'''
        self.window = tk.Tk()
        #self.window.geometry("1000x600")
        self.window.title('Walk or Run in Rain')
        self.window.configure(background='#9b9b9b')
        
        # Large Frame
        self.win_frame = tk.Frame(self.window, width=1000, height=600, highlightbackground='#595959', highlightthickness=2)
        
        # menu (up side)
        #~ self.menu_label = tk.Label(self.menu, text="Settings", bg='#8a8a8a', font=("Courier", "16", "bold roman"))
        #~ self.mute = tk.Button(self.menu, text="XXXX", font="Courier", bg='#bcbcbc', activebackground='#cdcdcd')

        #~ tk.Button(self.menu, text="<->", command=lambda: setattr(self, "direction", (-self.direction[0], self.direction[1]))).pack()
        self.menu = tk.Frame(self.win_frame, width=1000, height=170, highlightbackground='#595959', highlightthickness=2)
        self.startButton = tk.Button(self.menu, text="START", font="Courier",bg='#bcbcbc', activebackground='#cdcdcd', \
                                        command = self.simulate)
        self.f1 = tk.Frame(self.menu, width=500, height=80)
        self.f2 = tk.Frame(self.menu, width=500, height=80)
        self.f3 = tk.Frame(self.menu, width=1000, height=80)
        self.label1 = tk.Label(self.menu, text = "Parametry modelu:")
        self.label2 = tk.Label(self.f3, text = "Energia:")
        self.label3 = tk.Label(self.f3, text = "Czas:")
        self.label4 = tk.Label(self.f3, text = "Ilość wody:")
        self.wynik1 = tk.Label(self.f3, text = '')
        self.wynik2 = tk.Label(self.f3, text = '')
        self.wynik3 = tk.Label(self.f3, text = '')
        self.pole_v_czlowieka = tk.Entry(self.f1, width = 30)
        self.pole_v_czlowieka.insert(END, 'Prędkość przemieszczania się')
        self.pole_v_wiatru = tk.Entry(self.f1, width = 30)
        self.pole_v_wiatru.insert(END, 'Prędkość wiatru')
        self.pole_wysokosc = tk.Entry(self.f1, width = 30)
        self.pole_wysokosc.insert(END, 'Wysokość ciała')
        self.pole_grubosc = tk.Entry(self.f2, width = 30)
        self.pole_grubosc.insert(END, 'Grubość ciała')
        self.pole_szerokosc = tk.Entry(self.f2, width = 30)
        self.pole_szerokosc.insert(END, 'Szerokość ciała')
        self.pole_masa = tk.Entry(self.f2, width = 30)
        self.pole_masa.insert(END, 'Masa człowieka')
        self.pole_dystans = tk.Entry(self.f2, width = 30)
        self.pole_dystans.insert(END, "Dystans")
        #~ self.combobox = ttk.Combobox(self.menu, width=27)
        #~ self.combobox['values'] = (
        #~ 'Pieszo', 'Rowerem')  # ustawienie elementów zawartych na liście rozwijanej
        #~ self.combobox.current(0)  # ustawienie domyślnego indeksu zaznaczenia
        
        # pygame
        self.pygame_frame = tk.Frame(self.win_frame, width=1000, height=430, highlightbackground='#595959', highlightthickness=2)

        # Packing
        self.win_frame.pack(expand=True)
        self.win_frame.pack_propagate(0)

        self.menu.pack(side="top")
        self.menu.pack_propagate(0)
        self.startButton.pack(ipadx=40, ipady=2, pady=5)
        self.label1.pack(side='top')
        self.f1.pack(side='top')
        self.f2.pack(side='top')
        self.f3.pack(side='bottom')
        self.label2.pack(side='left', padx=100)
        self.wynik1.pack(side='left')
        self.label3.pack(side='left', padx=100)
        self.wynik2.pack(side='left')
        self.label4.pack(side='left', padx=100)
        self.wynik3.pack(side='left')
        self.pole_v_czlowieka.pack(side='left')
        self.pole_v_wiatru.pack(side='left')
        self.pole_wysokosc.pack(side='left')
        self.pole_grubosc.pack(side='left')
        self.pole_szerokosc.pack(side='left')
        self.pole_masa.pack(side='left')
        self.pole_dystans.pack(side='left')
        #~ self.combobox.pack(side='top')

        self.pygame_frame.pack(side="bottom")
        #This embeds the pygame window
        os.environ['SDL_WINDOWID'] = str(self.pygame_frame.winfo_id())
        system = platform.system()
        if system == "Windows":
            os.environ['SDL_VIDEODRIVER'] = 'windib'
        elif system == "Linux":
            os.environ['SDL_VIDEODRIVER'] = 'x11'
            

        self.window.update_idletasks()
        self.window.mainloop()
        
        
        #Start pygame
    def simulate(self):
        self.wynik1['text'] = ''
        self.wynik2['text'] = ''
        self.wynik3['text'] = ''
        pygame.init()
        self.win = pygame.display.set_mode((1000, 430))
        self.background_image = loadImage("tlo.jpg")
        self.win.blit(self.background_image,(0,0))
        
        self.sim = True
        self.walkCounter = 0
        self.vy = 10
        self.vx = 0
        self.q = 0.005      #gęstość deszczu l/m^3
        self.d = 100        #długość trasy
        self.wys = 1.7
        self.szer = 0.45
        self.grub = 0.2
        self.masa = 65
        if isfloat(self.pole_v_wiatru.get()):
            self.vx = float(self.pole_v_wiatru.get())
        if isfloat(self.pole_wysokosc.get()):
            self.wys = float(self.pole_wysokosc.get())
        if isfloat(self.pole_szerokosc.get()):
            self.szer = float(self.pole_szerokosc.get())
        if isfloat(self.pole_grubosc.get()):
            self.grub = float(self.pole_grubosc.get())
        if isfloat(self.pole_masa.get()):
            self.masa = float(self.pole_masa.get())
        if isfloat(self.pole_dystans.get()):
            self.d = float(self.pole_dystans.get())
        self.ludzikSprite = pygame.sprite.RenderClear()
        self.kroplaSprites = pygame.sprite.RenderClear()
        self.ludzik = Ludzik()  
        if isfloat(self.pole_v_czlowieka.get()):
            self.ludzik.velocity = float(self.pole_v_czlowieka.get())
        self.ludzikSprite.add(self.ludzik)                #dodaj go do grupy
        self.time = self.d/self.ludzik.velocity
        self.time = round(self.time,4)
        self.met = findmet(self.ludzik.velocity)
        self.energy = 0.0002917*self.met*self.masa*self.time
        self.energy = round(self.energy,4)
        self.avert = self.szer*self.wys
        self.ahor = self.szer*self.grub
        self.qtot = self.q*self.d*(self.ahor*self.vy/self.ludzik.velocity+self.avert*\
                        abs(self.vx-self.ludzik.velocity)/self.ludzik.velocity)
        self.qtot = round(self.qtot,4)
        xs = np.random.randint(0,SCREEN_WIDTH,30)
        ys = np.random.randint(0,30,300)
        self.krople = [Raindrop((x,y)) for x,y in zip(xs, ys)]
        for kr in self.krople:
            kr.x = self.vx
            kr.y = self.vy
            self.kroplaSprites.add(kr)
        self.window.after(10, self.update)
        


    def update(self):
        if not self.sim:
            pygame.quit()
            self.wynik1['text'] = str(self.energy)+' (Kcal)'
            self.wynik2['text'] = str(self.time)+' (s)'
            self.wynik3['text'] = str(self.qtot)+ ' (l)'
        else:
            self.win.blit(self.background_image,(0,0))
            self.ludzikSprite.update()
            self.kroplaSprites.update()
            self.ludzikSprite.clear(self.win, self.background_image)
            self.kroplaSprites.clear(self.win, self.background_image)
            self.walkCounter += 1
            if self.walkCounter > 35:
                self.walkCounter = 0
            if self.walkCounter%6 == 0:
                self.ludzik.image = self.ludzik.ims[int(self.walkCounter/6)]
            for i in range(3):
                x = np.random.randint(0,SCREEN_WIDTH)
                y = np.random.randint(0,300)
                kr = Raindrop((x,y))
                kr.x = self.vx
                kr.y = self.vy
                self.kroplaSprites.add(kr)
            if self.ludzik.rect.right > SCREEN_WIDTH: 
                self.sim = False
            pygame.sprite.spritecollide(self.ludzik, self.kroplaSprites,True)
                    
            self.ludzikSprite.draw(self.win)
            self.kroplaSprites.draw(self.win)
            
            
            pygame.display.flip()
            self.window.after(10, self.update)
            if self.ludzik.rect.right > SCREEN_WIDTH: 
                self.sim = False


apl = Application()
