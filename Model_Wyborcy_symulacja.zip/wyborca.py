import numpy as np
import matplotlib.pyplot as plt
import time
import random

def simulate(N, dx, L):
    b = []
    for i in range(N+2):
        b.append(i)
    b[N] = 0
    b[-1] = N-1
    xs = np.arange(0, 1+dx, dx)
    start = time.time()
    avTimeArr = []
    posProbArr = []
    GTC = 0
    for x in xs:
        NPlus = int(N*x)
        pluses = np.ones(NPlus)
        minuses = (-1)*np.ones(N-NPlus)
        pool = np.concatenate((pluses, minuses))
        counts = []
        positive = 0
        for attempt in range(L):
            indexes = random.sample(range(N),N)
            agents = []
            for i in indexes:
                agents.append(pool[i])
            count = 0
            while not abs(sum(agents))/N == 1:
                randAg = np.random.randint(0,N, N)
                randTmp = np.random.randint(0,2,N)
                randNeigh = [(-1)**i for i in randTmp]
                for j, value  in enumerate(randAg):
                    agents[value] = agents[b[value+randNeigh[j]]]
                GTC += N
                count += 1
            if sum(agents)/N == 1:
                positive += 1
            counts.append(count)
        avTime = sum(counts)/L
        avTimeArr.append(avTime)
        posProb = positive/L
        posProbArr.append(posProb)
        print(x)    # For progress monitoring
    finish = time.time()
    name = "N"+str(N)+"dx"+str(dx)+"L"+str(L)+".txt"
    f = open(name, "a")
    for i in range(len(xs)):
        f.write(str(xs[i])+" "+str(posProbArr[i])+" "+str(avTimeArr[i])+"\n")
    f.close()
    # Time monitoring
    print("Average MCS: ",sum(avTimeArr)/len(xs))
    print("Executing time: ", finish-start)
    print("Time per iteration: ", (finish-start)/GTC)
    
    
    
if __name__ == "__main__":
    simulate(40, 0.02, 1000)