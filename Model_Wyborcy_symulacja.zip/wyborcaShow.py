import matplotlib.pyplot as plt

'''UWAGA! Zeby program dzialal, wszystkie zestawy danych
musza znajdowac sie w jednym folderze z programem'''

# ZESTAW 1
xs1 = []
probs1 = []
times1 = []
N1 = [100, 500, 1000]
for N in N1:
    xstmp = []
    probstmp = []
    timestmp = []
    f = open("N"+str(N)+"dx0.02L100.txt", 'r')
    for line in f:
        tmp = line.split()
        xstmp.append(float(tmp[0]))
        probstmp.append(float(tmp[1]))
        timestmp.append(float(tmp[2]))
    xs1.append(xstmp)
    probs1.append(probstmp)
    times1.append(timestmp)
    f.close()
styles = ['-', '--', ':']
for xs, probs, i in zip(xs1, probs1, range(3)):
    plt.plot(xs, probs, ls=styles[i], label="N = "+str(N1[i]))
    plt.scatter(xs, probs, s=5, marker='o')
plt.xlabel("Koncentracja pozytywnej opinii, x")
plt.ylabel("P-stwo pozytywnego konsensusu, P+")
plt.legend()
plt.show()
for xs, times, i in zip(xs1, times1, range(3)):
    plt.plot(xs, times, ls=styles[i], label="N = "+str(N1[i]))
    plt.scatter(xs, times, s=10, marker='o')
plt.xlabel("Koncentracja pozytywnej opinii, x")
plt.ylabel("Czas dochodzenia do konsensusu, [MCS]")
plt.legend()
plt.show()

# ZESTAW 2
xs2 = []
probs2 = []
times2 = []
N2 = [100, 200, 300]
for N in N2:
    xstmp = []
    probstmp = []
    timestmp = []
    f = open("N"+str(N)+"dx0.02L1000.txt", 'r')
    for line in f:
        tmp = line.split()
        xstmp.append(float(tmp[0]))
        probstmp.append(float(tmp[1]))
        timestmp.append(float(tmp[2]))
    xs2.append(xstmp)
    probs2.append(probstmp)
    times2.append(timestmp)
    f.close()
styles = ['-', '--', ':']
for xs, probs, i in zip(xs2, probs2, range(3)):
    plt.plot(xs, probs, ls=styles[i], label="N = "+str(N2[i]))
    plt.scatter(xs, probs, s=5, marker='o')
plt.xlabel("Koncentracja pozytywnej opinii, x")
plt.ylabel("P-stwo pozytywnego konsensusu, P+")
plt.legend()
plt.show()
for xs, times, i in zip(xs2, times2, range(3)):
    plt.plot(xs, times, ls=styles[i], label="N = "+str(N2[i]))
    plt.scatter(xs, times, s=10, marker='o')
plt.xlabel("Koncentracja pozytywnej opinii, x")
plt.ylabel("Czas dochodzenia do konsensusu, [MCS]")
plt.legend()
plt.show()

# ZESTAW3
names = ["N30dx0.02L1000.txt","N40dx0.02L1000.txt","N50dx0.02L1000.txt", \
"N70dx0.02L1000.txt", "N100dx0.02L1000.txt", "N200dx0.02L1000.txt", \
"N300dx0.02L1000.txt", "N400dx0.02L100.txt", "N500dx0.02L100.txt"]
names1 = ["N700dx0.05L20.txt", "N800dx0.05L20.txt", "N1000dx0.02L100.txt"]
indtmp = [10, 10, 25]
ns = [30, 40, 50, 70, 100, 200, 300, 400, 500, 700, 800, 1000]
ts = []
for name in names:
    xstmp = []
    probstmp = []
    timestmp = []
    f = open(name, 'r')
    for line in f:
        tmp = line.split()
        xstmp.append(float(tmp[0]))
        probstmp.append(float(tmp[1]))
        timestmp.append(float(tmp[2]))
    f.close()
    ts.append(timestmp[25])
for name, i in zip(names1, indtmp):
    xstmp = []
    probstmp = []
    timestmp = []
    f = open(name, 'r')
    for line in f:
        tmp = line.split()
        xstmp.append(float(tmp[0]))
        probstmp.append(float(tmp[1]))
        timestmp.append(float(tmp[2]))
    f.close()
    ts.append(timestmp[i])
plt.plot(ns, ts)
plt.scatter(ns, ts, s=5)
plt.xlabel("Liczba agentów, N")
plt.ylabel("Czas dochodzenia do konsensusu dla x=0.5, [MCS]")
plt.show()