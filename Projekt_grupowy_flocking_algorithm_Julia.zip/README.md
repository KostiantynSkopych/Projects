# julia
projekt narzedzia obliczeniowe 2020

# start
Aby program zadziałał należy uruchowić plik julia-flock.jl w src, z folderem src jako working directory

biblioteki z których korzystaliśmy to:
Gtk
Plots

oraz obejście problemu braku multitaskingu autorstwa Tobias.Knopp
