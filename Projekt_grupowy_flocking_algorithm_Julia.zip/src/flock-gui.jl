module Flock_GUI
using Gtk
export open_window

  mutable struct MyState
  task::Union{Task,Nothing}
  end

    # frames = 100

  function open_window(new_frame, delta_time)

      function asyncDo()
        state = MyState(nothing)
        state.task = Task(()->asyncDoInner(state))
        schedule(state.task)
        return state
      end

      function asyncDoInner(state::MyState)
          while true
              new_frame()
              sleep(delta_time)
              yield()
          end
      end

      function simulate_button(w)
        state = asyncDo()
        timer = nothing
          function update(::Timer)
            if Base.istaskfailed(state.task)
              close(timer)
              error("something is wrong")
              return
            end
            set_gtk_property!(single_frame, :file, "images/single_frame.png")
            if istaskdone(state.task)
              close(timer)
            end
            return
          end
        timer = Timer(update, 0.0, interval=delta_time)
        return
      end

      win = GtkWindow("julia-flock", 600, 400)
      single_frame = GtkImage("images/background.png")
      b = GtkButton("Zacznij flocking")
        signal_connect(simulate_button, b, "clicked")
      hbox = GtkBox(:v)
      push!(win, hbox)
      push!(hbox, b)
      push!(hbox, single_frame)

      showall(win)

  end
end
