"""
glowny modul

julia-flock
program symulacji zachowania stadnego uzywajacy "boids/flocking algorithm"
stworzony na narzedzia obliczniowe

tworcy:
Michał Bukowski
Kostia Skopych
Maciej Antoni Ratajski
"""
# FIXME tu sie podpiszcie jak chcecie przepisalem z fejsa XD

include("flocking.jl")
using .Flocking
include("flock-2d.jl")
using .Single_frame
include("flock-gui.jl")
using .Flock_GUI

function main()
    # przykladowy kod i trzeba dopasowac wartosci w WorldSettings ale to jak bedzie grafika
    world = Main.Flocking.World([], [], Main.Flocking.WorldSettings(5, 1, 10, 5, 3, 20, 1, 3))
    delta_time = 0.04
    # wymiary świata
    dim_x, dim_y = (10, 10)
    number_of_boids, number_of_obstacles = 20, 10
    # generowanie boidów w ustalonej pozycji i losowych
    for i in 1:number_of_boids
        Main.Flocking.add_boid(world::Main.Flocking.World, [rand()*dim_x, rand()*dim_y], [rand(), rand()])
    end
    for i in 1:10
        Main.Flocking.add_boid(world, [1.0,i*0.75+1.0],[0.5,0.8])
    end
    for i in 1:10
        Main.Flocking.add_boid(world, [9.0,i*0.75+1.0],[0.5,0.8])
    end
    # generowanie przeszkód losowych i na krańcach
    for i in 1:number_of_obstacles
        Main.Flocking.add_obstacle(world::Main.Flocking.World,[rand()*dim_x,rand()*dim_y])
    end
    for i in 1:0.5:10
        add_obstacle(world,[0.,i*1.0])
        add_obstacle(world,[10.,i*1.0])
        add_obstacle(world,[i*1.0,10.0])
        add_obstacle(world,[i*1.0,0.0])
    end
    # co dzieje się przy każdej klatce
    function new_frame()
        single_frame(world)
        simulate(world, delta_time)
    end

    # wyświetlamy okno przekazując new_frame, delta_time
    open_window(new_frame, delta_time)
end

main()
