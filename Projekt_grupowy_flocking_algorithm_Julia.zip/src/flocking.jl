"""
modul zachowan stadnych
"""

module Flocking

abs2(vector::Vector) = sum(vector.^2)
abs(vector::Vector) = broadcast(sqrt, abs2(vector))
norm(vector::Vector) = vector ./ abs(vector)

export World, Obstacle, Boid, WorldSettings,
    add_to_world, add_obstacle, add_boid, simulate

struct WorldSettings
    flock_neightbour_radius # odleglosc szukania innych boidow dla cohesion_rule i alignment_rule
    separation_neightbour_radius # odleglosc szukania przeszkod/innych boidow do omijania ich
    cohesion_multiplier # jak bardzo boidy daza do bycia blisko siebie
    alignment_multiplier # jak bardzo boidy daza do poruszania sie w tym samym kierunku i szybkosci
    avoid_colisions_multiplier # jak bardzo boidy omijaja inne boidy
    avoid_obstacles_multiplier # jak bardzo boidy omijaja pzreszkody
    boid_inertia # im wieksza inercja tym boidy mniej reaguja na sygnaly z otoczenia
    boid_speed # dodatnia wartosc ustawia predkosc z jaka poruszaja sie boidy
end

mutable struct World
    boids::Vector
    obstacles::Vector

    settings::WorldSettings
end

struct Obstacle
    position::Vector
end

struct Boid
    position::Vector
    velocity::Vector

    world_weakreference::WeakRef
end

function add_to_world(world::World, obstacle::Obstacle)
    push!(world.obstacles, obstacle)
end

function add_to_world(world::World, boid::Boid)
    push!(world.boids, boid)
end

function change_world_settings(world, settings)
    world.settings = settings
end

function add_obstacle(world::World, position::Vector)
   add_to_world(world, Obstacle(position)) 
end

function add_boid(world::World, position::Vector, velocity::Vector)
    add_to_world(world, Boid(position, velocity, WeakRef(world)))
end

function simulate(world::World, delta_time)
    """
    symuluj zmiane stanu swiata o kroku delta_time

    wywoluje operacje liczenia nowej pozycji u kazdego boid.
    boid liczy swoja nowa pozycje na podstawie STAREGO polozenia pozostalych
    tak wiec sa one immutable i tworzony jest nowy obiekt boid
    """

    world.boids = broadcast(simulate_boid, world.boids, delta_time)
end

function meanposition(neightbours::Vector)
    
    neightbours_count = length(neightbours)
    vector_sum = copy(neightbours[1].position)
    
    for i in 2:neightbours_count
        vector_sum .+= neightbours[i].position
    end
    
    return vector_sum ./ neightbours_count
end

function meanvelocity(neightbours::Vector)
    
    neightbours_count = length(neightbours)
    vector_sum = copy(neightbours[1].velocity)
    
    for i in 2:neightbours_count
        vector_sum .+= neightbours[i].velocity
    end
    
    return vector_sum ./ neightbours_count
end

function cohesion_rule(boid::Boid, neightbours_in_cohesion_distance::Vector)
    """
    zwraca wektor w ktorym boid powinien podazac aby znalezc sie w centrum swojego flocka
    
    dlugosc wektora oznacza jak wazne jest podazanie w tym kierunku
    """
    
    if length(neightbours_in_cohesion_distance) > 0
        return meanposition(neightbours_in_cohesion_distance) .- boid.position
    else
        return zeros(length(boid.velocity))
    end
end

function alignment_rule(boid::Boid, neightbours_in_alignment_distance::Vector)
    """
    zwraca wektor w ktorym boid powinien podazac aby podazac w kierunku podobnym do reszty boidow w flocku
    
    dlugosc wektora oznacza jak wazne jest podazanie w tym kierunku
    """
    
    if length(neightbours_in_alignment_distance) > 0
        return meanvelocity(neightbours_in_alignment_distance) .- boid.velocity
    else
        return zeros(length(boid.velocity))
    end
end

function close_entities(boid::Boid, entities::Vector, neightbourhood_radius)

    neightbours = []
    for potential_neightbour in entities
        
        if potential_neightbour !== boid && abs2(potential_neightbour.position .- boid.position) <= neightbourhood_radius

            push!(neightbours, potential_neightbour)
        end
    end

    return neightbours
end

function separation_rule(boid::Boid, neightbours_in_separation_distance::Vector)
    """
    zwraca wektor w ktorym boid podazajac bedzie najszybciej oddalal sie od zderzenia
    kierunek gradientu spadajacego potencjalu (w analogii do elektronow)

    dlugosc wektora oznacza jak wazne jest podazanie w tym kierunku
    """

    if length(neightbours_in_separation_distance) > 0

        unit_separation_force = zeros(length(boid.position))
        for neightobur in neightbours_in_separation_distance

            position_difference = boid.position .- neightobur.position
            unit_separation_force = unit_separation_force .+ norm(position_difference) ./ abs2(position_difference)
        end

        return unit_separation_force ./ length(neightbours_in_separation_distance)
    else
        return zeros(length(boid.position))
    end
end

function simulate_boid(boid::Boid, delta_time)

    flock_neightbours = close_entities(boid, boid.world_weakreference.value.boids, boid.world_weakreference.value.settings.flock_neightbour_radius)
    separation_neightbours = close_entities(boid, boid.world_weakreference.value.boids, boid.world_weakreference.value.settings.separation_neightbour_radius)
    separation_obstacles = close_entities(boid, boid.world_weakreference.value.obstacles, boid.world_weakreference.value.settings.separation_neightbour_radius)
    
    # mozliwe ze potrzebne sa kierunki nie wektory w ktora strone podazajac
    
    cohesion = cohesion_rule(boid, flock_neightbours)
    alignment = alignment_rule(boid, flock_neightbours)
    boid_separation = separation_rule(boid, separation_neightbours)
    obstacles_separation = separation_rule(boid, separation_obstacles)
    
    total_force = 
        boid.world_weakreference.value.settings.cohesion_multiplier .* cohesion .+
        boid.world_weakreference.value.settings.alignment_multiplier .* alignment .+
        boid.world_weakreference.value.settings.avoid_colisions_multiplier .* boid_separation .+
        boid.world_weakreference.value.settings.avoid_obstacles_multiplier .* obstacles_separation

    velocity = boid.velocity .+ (total_force ./ boid.world_weakreference.value.settings.boid_inertia) .* (delta_time / 2)
    if boid.world_weakreference.value.settings.boid_speed > 0
        # jezeli jest ustawiona predkosc z jaka maja sie poruszac
       velocity = norm(velocity) .* boid.world_weakreference.value.settings.boid_speed
   end

    position = boid.position .+ velocity .* delta_time

    return Boid(
        position,
        velocity,
        boid.world_weakreference
        )
end

end