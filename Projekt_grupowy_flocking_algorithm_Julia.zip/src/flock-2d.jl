module Single_frame
using Plots
export single_frame

    function single_frame(world::Main.Flocking.World)
        p=plot(xlims=(-0.01,10),ylims=(-0.1,10),legend=false)
        for b in world.boids
            quiver!([b.position[1]],[b.position[2]],quiver=([b.velocity[1]]/3,[b.velocity[2]]/3))
        end
        for o in world.obstacles
            scatter!([o.position[1]],[o.position[2]])
        end
        savefig(p,"images/single_frame.png")
    end
end
